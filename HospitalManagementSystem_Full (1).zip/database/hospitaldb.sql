
CREATE DATABASE hospitaldb;
USE hospitaldb;

CREATE TABLE patients(
patient_id INT PRIMARY KEY,
name VARCHAR(50),
age INT,
disease VARCHAR(100)
);
