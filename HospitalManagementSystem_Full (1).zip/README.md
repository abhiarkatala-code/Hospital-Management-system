# Hospital Management System

Java Swing + JDBC + MySQL project.

## Features
- Patient Registration
- Appointment Booking
- Billing
- Medical Records

## Setup
1. Install MySQL.
2. Run database/hospitaldb.sql
3. Add MySQL Connector/J.
4. Update DB credentials in DBConnection.java.
5. Compile and run HospitalManagementSystem.java.
