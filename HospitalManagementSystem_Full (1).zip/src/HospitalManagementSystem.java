
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class HospitalManagementSystem extends JFrame {

    JTextField pid,name,age,disease,doctor,date,billAmount,record;
    JTextArea output;

    public HospitalManagementSystem(){
        setTitle("Hospital Management System");
        setSize(900,650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();

        JPanel patient = new JPanel(new GridLayout(5,2));
        pid=new JTextField(); name=new JTextField(); age=new JTextField(); disease=new JTextField();
        JButton add=new JButton("Register Patient");
        patient.add(new JLabel("Patient ID")); patient.add(pid);
        patient.add(new JLabel("Name")); patient.add(name);
        patient.add(new JLabel("Age")); patient.add(age);
        patient.add(new JLabel("Disease")); patient.add(disease);
        patient.add(add);

        JPanel app=new JPanel(new GridLayout(4,2));
        doctor=new JTextField(); date=new JTextField();
        JButton book=new JButton("Book Appointment");
        app.add(new JLabel("Doctor")); app.add(doctor);
        app.add(new JLabel("Date")); app.add(date);
        app.add(book);

        JPanel bill=new JPanel(new GridLayout(3,2));
        billAmount=new JTextField();
        JButton genBill=new JButton("Generate Bill");
        bill.add(new JLabel("Amount")); bill.add(billAmount);
        bill.add(genBill);

        JPanel rec=new JPanel(new GridLayout(3,2));
        record=new JTextField();
        JButton saveRec=new JButton("Save Record");
        rec.add(new JLabel("Record")); rec.add(record);
        rec.add(saveRec);

        tabs.add("Patients",patient);
        tabs.add("Appointments",app);
        tabs.add("Billing",bill);
        tabs.add("Records",rec);

        output=new JTextArea();
        add(tabs,BorderLayout.CENTER);
        add(new JScrollPane(output),BorderLayout.SOUTH);

        add.addActionListener(e->registerPatient());
        book.addActionListener(e->output.append("Appointment Booked\n"));
        genBill.addActionListener(e->output.append("Bill Generated\n"));
        saveRec.addActionListener(e->output.append("Medical Record Saved\n"));

        setVisible(true);
    }

    void registerPatient(){
        try{
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
            "INSERT INTO patients VALUES(?,?,?,?)");
            ps.setInt(1,Integer.parseInt(pid.getText()));
            ps.setString(2,name.getText());
            ps.setInt(3,Integer.parseInt(age.getText()));
            ps.setString(4,disease.getText());
            ps.executeUpdate();
            output.append("Patient Registered Successfully\n");
        }catch(Exception ex){
            output.append("Error: "+ex.getMessage()+"\n");
        }
    }

    public static void main(String[] args){
        new HospitalManagementSystem();
    }
}
